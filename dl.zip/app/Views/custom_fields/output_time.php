<?php

if (is_date_exists($value)) {
    echo format_to_time($value, false);
}
?>