<div class="table-responsive">
    <table id="yearly-estimate-table" class="display" cellspacing="0" width="100%">   
    </table>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        loadEstimatesTable("#yearly-estimate-table", "yearly");
    });
</script>