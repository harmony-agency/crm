<div class="table-responsive">
    <table id="yearly-invoice-payment-table" class="display" width="100%">
    </table>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        loadPaymentsTable("#yearly-invoice-payment-table", "yearly");
    });
</script>