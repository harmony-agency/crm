<div class="table-responsive">
    <table id="custom-invoice-payment-table" class="display" cellspacing="0" width="100%">   
    </table>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        loadPaymentsTable("#custom-invoice-payment-table", "custom");
    });
</script>