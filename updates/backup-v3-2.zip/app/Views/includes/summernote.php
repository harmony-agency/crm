<?php

load_css(array(
    "assets/js/summernote/summernote.css",
));
load_js(array(
    "assets/js/summernote/summernote.min.js", 
    "assets/js/summernote/lang/summernote-" . app_lang('language_locale_long') . ".js"
));

