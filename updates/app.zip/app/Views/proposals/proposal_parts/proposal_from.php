<?php

echo company_widget($proposal_info->company_id);
