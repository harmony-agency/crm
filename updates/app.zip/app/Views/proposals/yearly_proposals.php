<div class="table-responsive">
    <table id="yearly-proposal-table" class="display" cellspacing="0" width="100%">   
    </table>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        loadProposalsTable("#yearly-proposal-table", "yearly");
    });
</script>